import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

export default function StudentForm() {
    const [student, setStudent] = useState({
        name: '',
        email: '',
        age: '',
        course: '',
    });

    const [nameError, setNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [ageError, setAgeError] = useState('');
    const [courseError, setCourseError] = useState('');
    const [successMsg, setSuccessMsg] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const handleChange = (e) => {
        const { name, value } = e.target;
        setStudent((prev) => ({
            ...prev,
            [name]: value,
        }));

        // Real-time validation
        if (name === 'name') {
            if (!value.trim()) {
                setNameError('Name is required.');
            } else if (!/^[a-zA-Z\s]+$/.test(value)) {
                setNameError('Name can only contain letters and spaces.');
            } else {
                setNameError('');
            }
        } else if (name === 'email') {
            if (!value.trim()) {
                setEmailError('Email is required.');
            } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(value)) {
                setEmailError('Invalid email format.');
            } else {
                setEmailError('');
            }
        } else if (name === 'age') {
            if (!value.trim()) {
                setAgeError('Age is required.');
            } else if (isNaN(Number(value)) || Number(value) <= 0) {
                setAgeError('Age must be a positive number.');
            } else {
                setAgeError('');
            }
        } else if (name === 'course') {
            if (!value.trim()) {
                setCourseError('Course is required.');
            } else {
                setCourseError('');
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        let hasErrors = false;

        // Final validation before submission
        if (!student.name.trim()) {
            setNameError('Name is required.');
            hasErrors = true;
        } else if (!/^[a-zA-Z\s]+$/.test(student.name)) {
            setNameError('Name can only contain letters and spaces.');
            hasErrors = true;
        } else {
            setNameError('');
        }

        if (!student.email.trim()) {
            setEmailError('Email is required.');
            hasErrors = true;
        } else if (!/^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(student.email)) {
            setEmailError('Invalid email format.');
            hasErrors = true;
        } else {
            setEmailError('');
        }

        if (!student.age.trim()) {
            setAgeError('Age is required.');
            hasErrors = true;
        } else if (isNaN(Number(student.age)) || Number(student.age) <= 0) {
            setAgeError('Age must be a positive number.');
            hasErrors = true;
        } else {
            setAgeError('');
        }

        if (!student.course.trim()) {
            setCourseError('Course is required.');
            hasErrors = true;
        } else {
            setCourseError('');
        }

        if (!hasErrors) {
            try {
                const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(student),
                });

                if (!response.ok) {
                    throw new Error('Failed to submit student data.');
                }

                const data = await response.json();
                setSuccessMsg(`Student registered successfully with ID: ${data.id}`);
                setErrorMsg('');
                setStudent({ name: '', email: '', age: '', course: '' });
            } catch (error) {
                setErrorMsg(error.message);
                setSuccessMsg('');
            }
        }
    };

    return (
        <>
            <Helmet>
                <title>Student Registration Form</title>
            </Helmet>
            <div className="container">
                <div className="page">
                    <div className="page-heading">
                        <h1>Student Registration</h1>
                        <span>
                            <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Student Registration</Link>
                        </span>
                    </div>
                    <div className="page-content">
                        <div className="portal">
                            <div className="portal-body">
                                <div className="form">
                                    <form onSubmit={handleSubmit} className="p-3 border rounded shadow-sm">
                                        <div className="row">
                                            <div className="col-12 mb-3">
                                                <h4 className="fw-bold">Register New Student</h4>
                                            </div>

                                            <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                                                <div className={`mb-3 ${nameError && 'has-error'}`}>
                                                    <label className="form-label">Name:</label>
                                                    <input
                                                        type="text"
                                                        name="name"
                                                        value={student.name}
                                                        onChange={handleChange}
                                                        className="form-control"
                                                        required
                                                    />
                                                    {nameError && <div className="text-danger">{nameError}</div>}
                                                </div>
                                            </div>

                                            <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                                                <div className={`mb-3 ${emailError && 'has-error'}`}>
                                                    <label className="form-label">Email:</label>
                                                    <input
                                                        type="email"
                                                        name="email"
                                                        value={student.email}
                                                        onChange={handleChange}
                                                        className="form-control"
                                                        required
                                                    />
                                                    {emailError && <div className="text-danger">{emailError}</div>}
                                                </div>
                                            </div>

                                            <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                                                <div className={`mb-3 ${ageError && 'has-error'}`}>
                                                    <label className="form-label">Age:</label>
                                                    <input
                                                        type="number"
                                                        name="age"
                                                        value={student.age}
                                                        onChange={handleChange}
                                                        className="form-control"
                                                        required
                                                    />
                                                    {ageError && <div className="text-danger">{ageError}</div>}
                                                </div>
                                            </div>

                                            <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                                                <div className={`mb-3 ${courseError && 'has-error'}`}>
                                                    <label className="form-label">Course:</label>
                                                    <input
                                                        type="text"
                                                        name="course"
                                                        value={student.course}
                                                        onChange={handleChange}
                                                        className="form-control"
                                                        required
                                                    />
                                                    {courseError && <div className="text-danger">{courseError}</div>}
                                                </div>
                                            </div>

                                            <div className='clearfix'></div>

                                            <div className='col-12 text-end'>
                                                <div className="mb-3 d-flex gap-2 align-items-center justify-content-end">
                                                    <button type="reset" className="btn btn-danger same-height">
                                                        <i className="ri-reset-right-line"></i> Reset
                                                    </button>
                                                    <button type="submit" className="btn btn-success same-height py-1">
                                                        <i className="ri-check-fill"></i> Add Student
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                    {successMsg && <div className="alert alert-success mt-3">{successMsg}</div>}
                                    {errorMsg && <div className="alert alert-danger mt-3">{errorMsg}</div>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
