import React, { useState } from "react";
import { Helmet } from "react-helmet";
export default function GiftForm() {
  const [formData, setFormData] = useState({
    name: "",
    image: null,
  });
  const [errors, setErrors] = useState({});
  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const validExtensions = ["image/png", "image/jpeg", "image/jpg"];
      if (!validExtensions.includes(file.type)) {
        setErrors((prev) => ({
          ...prev,
          image: "Only PNG, JPEG, JPG formats are allowed.",
        }));
        return;
      }
      if (file.size > 5 * 1024) {
        setErrors((prev) => ({
          ...prev,
          image: "Image size must be less than 5KB.",
        }));
        return;
      }
      setErrors((prev) => ({
        ...prev,
        image: "",
      }));
      setFormData((prev) => ({ ...prev, image: file }));
    }
  };
  const validate = () => {
    const newErrors = {};
    // Name validation: Minimum 4 characters
    if (!formData.name.trim() || formData.name.trim().length < 4) {
      newErrors.name = "Name must be at least 4 characters long.";
    }
    // Image validation
    if (!formData.image) {
      newErrors.image = "Image is required.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log("Gift Data Submitted:", formData);
      alert("Gift added successfully!");
      // Reset form
      setFormData({
        name: "",
        image: null,
      });
    }
  };
  return (
    <>
      <Helmet>
        <title>Gift Form</title>
      </Helmet>
      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1>Add Gift</h1>
          </div>
          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <div className="form">
                  <form autoComplete="off" onSubmit={handleSubmit}>
                    <div className="row">
                      {/* Name */}
                      <div className="mb-3 col-lg-4 col-md-6 col-sm-12">
                        <label htmlFor="name" className="form-label">
                          Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          className="form-control"
                          value={formData.name}
                          onChange={handleChange}
                        />
                        {errors.name && (
                          <small className="text-danger">{errors.name}</small>
                        )}
                      </div>
                      {/* Image */}
                      <div className="mb-3 col-lg-4 col-md-6 col-sm-12">
                        <label htmlFor="image" className="form-label">
                          Image *
                        </label>
                        <input
                          type="file"
                          id="image"
                          className="form-control"
                          accept="image/png, image/jpeg, image/jpg"
                          onChange={handleImageChange}
                        />
                        {errors.image && (
                          <small className="text-danger">{errors.image}</small>
                        )}
                      </div>
                    </div>
                    {/* Buttons */}
                    <div className="clearfix"></div>
                    <div className="col-12 text-end">
                      <div className="mb-3 d-flex gap-2 align-items-center justify-content-end">
                        <button
                          type="reset"
                          className="btn btn-danger same-height"
                          onClick={() =>
                            setFormData({
                              name: "",
                              image: null,
                            })
                          }
                        >
                          <i className="ri-reset-right-line"></i> Reset
                        </button>
                        <button type="submit" className="btn btn-success">
                            
                          <i className="ri-check-fill"></i> Add Gift
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}






