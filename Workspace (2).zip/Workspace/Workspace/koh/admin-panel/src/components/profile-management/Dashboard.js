import React from 'react'
import { Link } from 'react-router-dom'

function Dashboard() {
  return (
    <>
      <div className='container'>

        {/* start of page */}
        <div className='page'>

          <div className='page-heading'>
            <h1>Dashboard</h1>
          </div>

          {/* start of page content */}
          <div className='page-content'>

            {/* start of dashboard counter section */}
            <div className='dashboard-counter-section'>
              <div className='row'>
                <div className='col-12 col-sm-6 col-md-4 col-lg-2'>
                  <div className='dashboard-counter'>
                    <i class="bi bi-people"></i>
                    <span className='counter-value'> 300 </span>
                    <b>Total Buyers</b>
                  </div>
                </div>
                <div className='col-12 col-sm-6 col-md-4 col-lg-2'>
                  <div className='dashboard-counter dashboard-counter-green'>
                    <i class="bi bi-cup-hot"></i>
                    <span className='counter-value'> 50 </span>
                    <b>Total Kitchens</b>
                  </div>
                </div>
                <div className='col-12 col-sm-6 col-md-4 col-lg-2'>
                  <div className='dashboard-counter dashboard-counter-red'>
                    <i class="bi bi-receipt"></i>
                    <span className='counter-value'> 300 </span>
                    <b>Today's Orders</b>
                  </div>
                </div>
                <div className='col-12 col-sm-6 col-md-4 col-lg-3'>
                  <div className='dashboard-counter dashboard-counter-blue'>
                    <i class="bi bi-currency-rupee"></i>
                    <span className='counter-value'> 13000 </span>
                    <b>Today Order Value</b>
                  </div>
                </div>
                <div className='col-12 col-sm-6 col-md-4 col-lg-3'>
                  <div className='dashboard-counter dashboard-counter-green'>
                    <i class="bi bi-currency-rupee"></i>
                    <span className='counter-value'> 1300 </span>
                    <b>Today's Oonovoo Value</b>
                  </div>
                </div>
              </div>
            </div>
            {/* end of dashboard counter section */}

            <div className='row'>
              
              <div className='col-lg-8 col-md-8 col-sm-12 col-12'>
                {/* start of portal content */}
                <div className="portal">
                  {/* start of portal title */}
                  <div className='portal-title-bar'>
                    <h4 className='portal-heading'>Latest Orders</h4>
                    <ul className='portal-actions'>
                      <li>
                        <Link to='#'>
                          <i className="bi bi-arrow-clockwise"></i>
                        </Link>
                      </li>
                    </ul>
                  </div>
                  {/* end of portal title */}

                  {/* start of portal body */}
                  <div className='portal-body'>
                    <div className='table-content'>
                      <table className='table table-bordered table-condensed'>
                        <thead>
                          <tr>
                            <th>Ref.No</th>
                            <th>Buyer</th>
                            <th>Kitchen</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {/* end of portal title */}

                </div>
                {/* end of portal content */}
              </div>

              <div className='col-lg-4 col-md-4 col-sm-12 col-12'>
                {/* start of portal content */}
                <div className="portal">
                  {/* start of portal title */}
                  <div className='portal-title-bar'>
                    <h4 className='portal-heading'>Today's Top Kitchen</h4>
                    <ul className='portal-actions'>
                      <li>
                        <Link to='#'>
                          <i className="bi bi-arrow-clockwise"></i>
                        </Link>
                      </li>
                    </ul>
                  </div>
                  {/* end of portal title */}

                  {/* start of portal body */}
                  <div className='portal-body'>
                    <div className='table-content'>
                      <table className='table table-bordered table-condensed'>
                        <thead>
                          <tr>
                            <th>Kitchen</th>
                            <th>Count</th>
                            <th>Value</th>
                          </tr>
                        </thead>
                        <tbody>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  {/* end of portal title */}

                </div>
                {/* end of portal content */}
              </div>

            </div>

          </div>
          {/* end of page content */}

        </div>
        {/* end of page */}

      </div>
    </>
  )
}

export default Dashboard