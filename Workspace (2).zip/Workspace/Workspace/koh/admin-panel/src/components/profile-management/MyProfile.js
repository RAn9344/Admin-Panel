import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import config from '../../config';
//import globalcontext
import { useGlobalContext } from '../../GlobalContext';
//import GenderGetAll
import { GenderGetAll } from '../../service/GenderService';
import { CityGetAll } from '../../service/CityService';

function MyProfile() {

  const { isLoading, setIsLoading, isAppError, setAppError, appErrorMessage, setAppErrorMessage, appErrorTitle, setAppErrorTitle, appErrorMode, setAppErrorMode, appUser } = useGlobalContext();

  const [genders, setGenders] = useState();
  const [citys, setCitys] = useState();
  //create useState for name, dob, email and mobile
  const [name, setName] = useState();
  const [dob, setDob] = useState();
  const [email, setEmail] = useState();
  const [mobile, setMobile] = useState();
  const [gender, setGender] = useState();
  const [city, setCity] = useState();

  const handleReset = () => {
    setName('');
    setDob('');
    setEmail('');
    setMobile('');
    setGender('');
    setCity('');
  };

  //call GenderGetAll on compnoent load
  React.useEffect(() => {
    const fetchGenders = async () => {
      try {
        setIsLoading(true);
        const responseGenders = await GenderGetAll();
        const responseCitys = await CityGetAll();
        setGenders(responseGenders.genders);
        setCitys(responseCitys.citys);
        setName(appUser.name);
        setEmail(appUser.email);
        setMobile(appUser.mobile);
        setCity(appUser.city.id);
        setGender(appUser.gender.id);
        //substr the first 10 chars from appUser.dob.date
        setDob(appUser.dob.date.substr(0, 10));
      } catch (error) {
        setAppError(true);
        setAppErrorTitle("Error");
        setAppErrorMessage("Failed to load data");
        setAppErrorMode("error");
      } finally {
        setIsLoading(false);
      }
    };

    fetchGenders();
  }, []);

  const updateProfile = async (event) => {
    try {
      event.preventDefault();
      setIsLoading(true);

      //check name is filled and min of 3 chars
      if (name.length < 3) {
        setAppError(true);
        setAppErrorTitle("Error");
        setAppErrorMessage("Name must be at least 3 characters");
        setAppErrorMode("error");
        return;
      }
    } catch (error) {
      setAppError(true);
      setAppErrorTitle("Error");
      setAppErrorMessage("Failed to update profile");
      setAppErrorMode("error");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>My Profile | {config.appName} </title>
      </Helmet>
      <div className='container'>
        <div className='page'>
          <div className='page-heading'>
            <h1>Update My Profile</h1>
            <span>
              <Link to="/"> Dashboard </Link> / My Profile
            </span>
          </div>
          <div className='page-content'>
            <div className="portal">
              <div className='portal-body'>
                <div className='form'>
                  <form onSubmit={updateProfile}>
                    <div className='row'>
                      <div className='col-12'>
                        <div className='mb-3'>
                          <h4>Profile Information</h4>
                        </div>
                      </div>
                      {/* Gender */}
                      <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="gender" className="form-label">Select Gender</label>
                          <select
                            className='form-control'
                            id="gender"
                            value={gender}
                            onChange={(e) => setGender(e.target.value)}
                          >
                            <option value="0">Select a gender</option>
                            {genders && genders.map((genderTemp) => (
                              <option key={genderTemp.id} value={genderTemp.id}>{genderTemp.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      {/* City */}
                      <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="city" className="form-label">Select City</label>
                          <select
                            className='form-control'
                            id="city"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                          >
                            <option value="0">Select a city</option>
                            {citys && citys.map((city) => (
                              <option key={city.id} value={city.id}>{city.name}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                      {/* Name */}
                      <div className='col-lg-6 col-md-6 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="firstname" className="form-label">Full Name</label>
                          <input
                            type="text"
                            className="form-control"
                            autoComplete='off'
                            id="firstname"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                          />
                        </div>
                      </div>
                      {/* DOB */}
                      <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="dob" className="form-label">Date Of Birth</label>
                          <input
                            type="date"
                            className="form-control"
                            autoComplete='off'
                            id="dob"
                            value={dob}
                            onChange={(e) => setDob(e.target.value)}
                          />
                        </div>
                      </div>
                      {/* Email */}
                      <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="email" className="form-label">Email</label>
                          <input
                            type="email"
                            className="form-control"
                            autoComplete='off'
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                          />
                        </div>
                      </div>
                      {/* Mobile */}
                      <div className='col-lg-3 col-md-3 col-sm-6 col-12'>
                        <div className="mb-3">
                          <label htmlFor="mobile" className="form-label">Mobile</label>
                          <input
                            type="text"
                            className="form-control"
                            autoComplete='off'
                            id="mobile"
                            maxLength="10"
                            minLength="10"
                            value={mobile}
                            onChange={(e) => setMobile(e.target.value)}
                          />
                        </div>
                      </div>
                      {/* Buttons */}
                      <div className='clearfix'></div>
                      <div className='col-12 text-end'>
                        <div className="mb-3">
                          <button
                            type='button'
                            className='btn btn-danger btn-md'
                            onClick={handleReset}
                          >
                            <i className="ri-reset-right-line"></i> Reset
                          </button>
                          &nbsp;&nbsp;
                          <button
                            type='submit'
                            onClick={updateProfile}
                            className='btn btn-success-app btn-md'
                          >
                            <i className="ri-check-fill"></i> Add Kitchen
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default MyProfile;