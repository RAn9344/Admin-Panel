import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faPlus } from '@fortawesome/free-solid-svg-icons';
import axios from 'axios';
// 🔧 Filter logic moved outside the component
function filterMembers(members, keyword, level, city) {
  return members.filter((member) =>
    (member.name.toLowerCase().includes(keyword.toLowerCase()) ||
      member.email.toLowerCase().includes(keyword.toLowerCase())) &&
    (level ? member.level === level : true) &&
    (city ? member.address.city === city : true)
  );
}

// ✅ TableMember component now receives data as a prop
const TableMember = ({ membersData }) => {
  const [keyword, setKeyword] = useState('');
  const [level, setLevel] = useState('');
  const [city, setCity] = useState('');
  const [members, setMembers] = useState(membersData); // Use the prop
  const [filteredMembers, setFilteredMembers] = useState(membersData); // Use the prop
  const [cities, setCities] = useState([]);

  useEffect(() => {
    // This effect runs when membersData changes (including initial render)
    setMembers(membersData);
    setFilteredMembers(membersData);
    // Calculate cities only once, when membersData is available.  Use a dependency array.
    if (membersData.length > 0) {
        setCities([...new Set(membersData.map(user => user.address.city))]);
    }

  }, [membersData]); // Dependency on membersData


  // 🔍 Filter logic on change
  useEffect(() => {
    const results = filterMembers(members, keyword, level, city);
    setFilteredMembers(results);
  }, [keyword, level, city, members]);

  const handleSearch = (e) => {
    e.preventDefault();
    const results = filterMembers(members, keyword, level, city);
    setFilteredMembers(results);
  };

  return (
    <div className="container">
      <div className="page">
        <div className="page-heading">
          <h1>Level wise</h1>
          <span>
            <Link to="/">Dashboard</Link> / <Link to="/kitchen/list">Level wise</Link>
          </span>
        </div>

        <div className="page-content">
          <div className="portal">
            <div className="portal-body">

              {/* 🔍 Search Form */}
              <form onSubmit={handleSearch}>
                <div className="row">

                  {/* Keyword Input */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label className="form-label">Keyword</label>
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Search by name or email"
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Level Dropdown */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label className="form-label">Level</label>
                      <select
                        className="form-select"
                        value={level}
                        onChange={(e) => setLevel(e.target.value)}
                      >
                        <option value="">-- Select Level --</option>
                        <option value="Beginner">Beginner</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Expert">Expert</option>
                      </select>
                    </div>
                  </div>

                  {/* City Dropdown */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12">
                    <div className="mb-3">
                      <label className="form-label">City</label>
                      <select
                        className="form-select"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                      >
                        <option value="">-- Select City --</option>
                        {cities.map((c, i) => (
                          <option key={i} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Search Button */}
                  <div className="col-lg-3 col-md-3 col-sm-6 col-12 d-flex align-items-end">
                    <div className="mb-3 w-100">
                      <button className="btn btn-secondary w-100" type="submit">
                        <FontAwesomeIcon icon={faSearch} /> Search
                      </button>
                    </div>
                  </div>
                </div>
              </form>

              {/* 🧾 Results Table */}
              <div className="table-content mt-3">
                <table className="table table-bordered table-condensed">
                  <thead>
                    <tr>
                      <th>S.No.</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Mobile</th>
                      <th>Whatsapp No</th>
                      <th>City</th>
                      <th>Gender</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredMembers.length > 0 ? (
                      filteredMembers.map((member, index) => (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td>{member.name}</td>
                          <td>{member.email}</td>
                          <td>{member.phone}</td>
                          <td>{member.whatsapp}</td>
                          <td>{member.address.city}</td>
                          <td>{member.gender}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="7" className="text-center">
                          No members found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* ➕ Add New Member */}
              <div className="text-end mt-3">
                <Link to="/member/add" className="btn btn-primary">
                  <FontAwesomeIcon icon={faPlus} /> Add New Member
                </Link>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ✅ Parent component to fetch data and pass it to TableMember
const MembersPage = () => {
  const [membersData, setMembersData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const response = await axios.get('https://jsonplaceholder.typicode.com/users');
        const data = response.data;

        const levels = ['Beginner', 'Intermediate', 'Expert'];
        const enhancedData = data.map(user => ({
          ...user,
          level: levels[Math.floor(Math.random() * levels.length)],
          whatsapp: user.phone,
          gender: Math.random() > 0.5 ? 'Male' : 'Female',
        }));

        setMembersData(enhancedData);
      } catch (error) {
        console.error('Error fetching users:', error.message);
        setError('Failed to load member data.');
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  if (loading) return <div>Loading members...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div>
      <h2>Member List</h2>
      <TableMember membersData={membersData} /> {/* ✅ Pass the data as a prop */}
    </div>
  );
};

export default MembersPage; // ✅  Export the parent component
