import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';

export default function FormTemplate() {
  const [formData, setFormData] = useState({
    mobile: '',
    unit: '',
    price: '',
    purchaseDateTime: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const validate = () => {
    const newErrors = {};

    // Mobile validation: must be exactly 10 digits
    if (!/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = 'Mobile number must be exactly 10 digits.';
    }

    // Unit validation: must not be empty
    if (!formData.unit.trim()) {
      newErrors.unit = 'Unit is required.';
    }

    // Price validation: must not be empty
    if (!formData.price.trim()) {
      newErrors.price = 'Price is required.';
    }

    // Purchase Date and Time validation: must not be in the future
    if (!formData.purchaseDateTime) {
      newErrors.purchaseDateTime = 'Purchase date and time is required.';
    } else {
      const selectedDate = new Date(formData.purchaseDateTime);
      const now = new Date();
      if (selectedDate > now) {
        newErrors.purchaseDateTime = 'Purchase date and time cannot be in the future.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const updateProfile = (e) => {
    e.preventDefault();
    if (validate()) {
      console.log('Epin created:', formData); // Log the form data
    }
  };

  return (
    <>
      <Helmet>
        <title>Form Template</title>
      </Helmet>
      <div className="container">
        <div className="page">
          <div className="page-heading">
            <h1> Add Epin</h1>
            <span>
              <Link to="/"> Dashboard </Link> / <Link to="/kitchen/list">Add Epin</Link>
            </span>
          </div>
          <div className="page-content">
            <div className="portal">
              <div className="portal-body">
                <div className="form">
                  <form autoComplete="off" onSubmit={updateProfile}>
                    <div className="row">
                     

                      {/* Mobile */}
                      <div className="mb-3 col-lg-4 col-md-4 col-sm-12">
                        <label className="form-label">Mobile Number *</label>
                        <input
                          type="tel"
                          id="mobile"
                          className="form-control"
                          value={formData.mobile}
                          onChange={handleChange}
                        />
                        {errors.mobile && <small className="text-danger">{errors.mobile}</small>}
                      </div>

                      {/* Unit */}
                      <div className="mb-3 col-lg-4 col-md-4 col-sm-12">
                        <label htmlFor="unit" className="form-label">Unit</label>
                        <input
                          type="number"
                          id="unit"
                          className="form-control"
                          value={formData.unit}
                          onChange={handleChange}
                        />
                        {errors.unit && <small className="text-danger">{errors.unit}</small>}
                      </div>

                      {/* Price */}
                      <div className="mb-3 col-lg-4 col-md-4 col-sm-12">
                        <label htmlFor="price" className="form-label">Price</label>
                        <input
                          type="number"
                          id="price"
                          className="form-control"
                          value={formData.price}
                          onChange={handleChange}
                        />
                        {errors.price && <small className="text-danger">{errors.price}</small>}
                      </div>

                      {/* Purchase Date Time */}
                      <div className="mb-3 col-lg-4 col-md-4 col-sm-12">
                        <label className="form-label">Purchase Date Time</label>
                        <input
                          type="datetime-local"
                          id="purchaseDateTime"
                          className="form-control"
                          value={formData.purchaseDateTime}
                          onChange={handleChange}
                        />
                        {errors.purchaseDateTime && (
                          <small className="text-danger">{errors.purchaseDateTime}</small>
                        )}
                      </div>
                      

                      {/* Buttons */}
                      <div className="clearfix"></div>
                      <div className="col-12 text-end">
                        <div className="mb-3">
                          <button
                            type="reset"
                            className="btn btn-danger btn-md"
                            onClick={() =>
                              setFormData({
                                mobile: '',
                                unit: '',
                                price: '',
                                purchaseDateTime: '',
                              })
                            }
                          >
                            <i className="ri-reset-right-line"></i> Reset
                          </button>
                          &nbsp;&nbsp;
                          <button
                            type="submit"
                            onClick={updateProfile}
                            className="btn btn-success"
                          >
                            <i className="ri-check-fill"></i> Add Epin
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}