import React from 'react';
//import fontawesome
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faCog,  faGift, faUsers, faBlog,  faFileAlt,faKey} from '@fortawesome/free-solid-svg-icons'; // Import specific icons
import { Link } from 'react-router-dom';
import { faLayerGroup } from '@fortawesome/free-solid-svg-icons'; // Import the Level icon


function SideBar() {
    return (
        <>
            <aside id='sidebar' className='sidebar'>
                <ul className='sidebar-nav' id='sidebar-nav'>
                    <li className='nav-item'>
                        <Link className='nav-link' to='/'>
                            <i><FontAwesomeIcon icon={faHome} /></i>
                            <span>Dashboard</span>
                        </Link>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#setting-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faCog} /></i>
                            <span>Settings</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='setting-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/setting/branding'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Genders</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/setting/adlogg'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Cities</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#epin-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faKey} /></i>
                            <span>Epin</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='epin-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/template/manage'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/epinpurchase/create'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>New Purchase</span>
                                </Link>
                            </li>
                             <li>
                                <Link to='/template/List'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#blog-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faBlog} /></i>
                            <span>Blog</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='blog-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                           
                            <li>
                                <Link to='/blog/ladd'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/blog/ledit'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Edit</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/blog/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Search</span>
                                </Link>
                            </li>
                             <li>
                                <Link to='/blogcategory/badd'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Category Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/blogcategory/bedit'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Category Edit</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/blogcategory/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Blog Category Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#level-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faLayerGroup} /></i> {/* Add the Level icon */}
                            <span>Level</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='level-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/level/add'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/level/edit'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Edit</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/level/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#brand-officer-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faUsers} /></i>
                            <span>Members</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='brand-officer-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/members/add'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/members/edit'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Edit</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/members/password/update'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Password Update</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/members/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>

                    <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#gift-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faGift} /></i>
                            <span>Gift</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='gift-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/gift/add'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Add</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/gift/edit'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Edit</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/gift/list'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Search</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                     <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#gift-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faFileAlt} /></i>
                            <span>Reports</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='gift-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/gift/levelwise'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Level Wise</span>
                                </Link>
                            </li>
                            <li>
                                <Link to='/gift/given'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Gift Giving</span>
                                </Link>
                            </li>
                           
                        </ul>
                    </li>
                     <li className='nav-item'>
                        <Link className='nav-link collapsed' data-bs-target="#gift-nav" data-bs-toggle="collapse" to='#'>
                            <i><FontAwesomeIcon icon={faFileAlt} /></i>
                            <span>Form</span>
                            <i className='bi bi-chevron-down ms-auto'></i>
                        </Link>
                        <ul id='gift-nav' className='nav-content collapse' data-bs-parent="#sidebar-nav">
                            <li>
                                <Link to='/form/post'>
                                    <FontAwesomeIcon icon="fa-solid fa-arrow-right-long" />
                                    <span>Post</span>
                                </Link>
                            </li>
                        </ul>
                    </li>
                </ul>
            </aside>
        </>
    )
}

export default SideBar;