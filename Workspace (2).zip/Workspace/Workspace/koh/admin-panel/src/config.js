// src/config.js
const applicationMode = "live";
var appName = "Oovanoo Office Administration";
var apiUrl = "https://oovanoo.com/api-2/";
var pageSize = 10;
var logo = "";

if (applicationMode === 'development') {
  appName = "Oovanoo Office Administration";
  apiUrl = "http://localhost/oovano-back-end-api/";
}
const config = {
  appName: appName,
  apiUrl: apiUrl,
  pageSize: pageSize,
  logo: logo,
};
export default config;