import axios from 'axios';
import config from '../config';

const GetAllMaster = async () => {
    try {
        const token = localStorage.getItem("oojwt");
        const response = await axios.get(config.apiUrl + 'kitchen/get-master', {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        if( response.status === 200 ){
            return {
                status: 200,
                citys: response.data.cities,
                genders: response.data.genders,
                allergys: response.data.foodAllergies,
                categorys: response.data.foodCategories,
                cusines: response.data.foodCusines,
                diets: response.data.foodDiets,
                times: response.data.foodTimes              
            };
        }
    } catch (error) {
        console.log(error);
        if( error.response.status === 401 ){
            return {
                status: 401,
                message: error.response.data.message
            };
        }
    }
}

export {GetAllMaster};