//icons
import "bootstrap-icons/font/bootstrap-icons.css";
import "remixicon/fonts/remixicon.css";

//bootstrap
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";

//font awesome
import { library } from "@fortawesome/fontawesome-svg-core";
import { fas } from "@fortawesome/free-solid-svg-icons";

import "./App.css";
import Header from "./components/navigation/Header";
import SideBar from "./components/side-navigation/SideBar";

//router
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Outlet,
  BrowserRouter,
} from "react-router-dom";
import Dashboard from "./components/profile-management/Dashboard";
import MyProfile from "./components/profile-management/MyProfile";
import { useGlobalContext } from "./GlobalContext";
import Login from "./components/general/Login";
import MyPassword from "./components/profile-management/MyPassword";
import { LoggedUserDetail } from "./service/UserService";
import { useEffect } from "react";
import CitiesTable from "./components/settings/CitiesTable";
import GenderTable from "./components/settings/GenderTable";
import TableTemplate from "./components/template/TableTemplate";
import FormTemplate from "./components/template/FormTemplate";
import LevelAdd from "./components/level/LevelAdd";
import LevelEdit from "./components/level/LevelEdit";
import LevelTable from "./components/level/LevelTable";
import BlogCategoryAdd from "./components/blogcategory/BlogCategoryAdd";
import BlogCategoryEdit from "./components/blogcategory/BlogCategoryEdit";
import TableCategory from "./components/blogcategory/TableCategory";
import BlogAdd from "./components/blog/BlogAdd";
import EditBlog from "./components/blog/EditBlog";
import TableBlog from "./components/blog/TableBlog";
import EpinNewPurchase from "./components/epinpurchase/EpinNewPurchase"
import AddMember from "./components/members/AddMember";
import MemberEdit from "./components/members/EditMember";
import MemberPasswordUpdate from "./components/members/MemberPasswordUpdate";
import TableMember from "./components/members/TableMember";
import GiftForm from "./components/gift/AddGift";
import GiftEdit from "./components/gift/EditGift";
import TableGift from "./components/gift/TableGift";
import LevelWise from "./components/reports/LevelWise";
import GiftGiven from "./components/reports/GiftGiven";
import PostForm from "./components/form/PostForm";

function App() {
  library.add(fas);

  const handleRetry = () => {
    setAppError(false); // Close the modal when retry is triggered
  };

  const makeLogout = () => {
    localStorage.removeItem("oojwt");
    setAppError(false); // Close the modal when retry is triggered
    setAppUser(null);
    setIsLogin(false);
  };

  const {
    isLoading,
    setIsLoading,
    isAppError,
    setAppError,
    appErrorMessage,
    setAppErrorMessage,
    appErrorTitle,
    setAppErrorTitle,
    appErrorMode,
    setAppErrorMode,
    appUser,
    setAppUser,
    isLogin,
    setIsLogin,
    isLogoutRequest,
    setIsLogoutRequest,
  } = useGlobalContext();

  //call LoggedUserDetail on component load using useEffect
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        setIsLoading(true);
        const response = await LoggedUserDetail();
        if (response.status === 200) {
          setAppUser(response.user);
          setIsLogin(true);
        }
      } catch (error) {
        setAppError(true);
        setAppErrorTitle("Error");
        setAppErrorMessage("Failed to load user details");
        setAppErrorMode("error");
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserDetails();
  }, []);

  useEffect(() => {
    document.querySelectorAll("input").forEach((input) => {
      input.setAttribute("autocomplete", "off");
    });
  }, []);

  return (
    <>
      {/* loading screen */}
      {isLoading && (
        <div className="loading-overlay">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}

      {/* Modal Error Message */}
      {isAppError && (
        <div
          className={appErrorMode + " app-error-message modal d-block"} // `d-block` ensures it always displays
          tabIndex="-1"
          role="dialog"
          aria-labelledby="errorModalLabel"
          aria-hidden="true"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }} // Optional backdrop styling
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="errorModalLabel">
                  {appErrorTitle}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={handleRetry}
                ></button>
              </div>
              <div className="modal-body">
                <p>{appErrorMessage}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Error Message */}
      {isLogoutRequest && (
        <div
          className={"warning app-error-message modal d-block"} // `d-block` ensures it always displays
          tabIndex="-1"
          role="dialog"
          aria-labelledby="errorModalLabel"
          aria-hidden="true"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }} // Optional backdrop styling
        >
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="errorModalLabel">
                  Logout confirmation
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  aria-label="Close"
                  onClick={handleRetry}
                ></button>
              </div>
              <div className="modal-body">
                <p>
                  Do you want to logout?
                  <br></br>
                  <br></br>
                  <button className="btn btn-success-app btn-md" type="button">
                    {" "}
                    No{" "}
                  </button>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <button
                    className="btn btn-danger btn-md"
                    type="button"
                    onClick={makeLogout}
                  >
                    {" "}
                    Yes{" "}
                  </button>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {isLogin ? (
        <>
          <main id="main" className="main">
            <BrowserRouter>
              <Header></Header>
              <SideBar></SideBar>
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/myprofile" element={<MyProfile />} />
                <Route path="/mypassword" element={<MyPassword />} />

                {/* Settings */}
                <Route path="/setting/adlogg" element={<CitiesTable />} />
                <Route path="/setting/branding" element={<GenderTable />} />


                {/* template */}

                <Route path="/template/manage" element={<FormTemplate />} />
                <Route path="/template/list" element={<TableTemplate />} />

                  {/* Epin New Purchase */}
                <Route path="/epinpurchase/create" element={<EpinNewPurchase />} />

                {/* Level */}

                <Route path="/level/add" element={<LevelAdd />} />
                <Route path="/level/edit" element={<LevelEdit />} />
                <Route path="/level/list" element={<LevelTable />} />

                {/* BlogCategory */}

                <Route path="/blogcategory/badd" element={<BlogCategoryAdd />} />
                <Route path="/blogcategory/bedit" element={<BlogCategoryEdit />} />
                <Route path="/blogcategory/list" element={<TableCategory />} />

                {/* Blog */}
                
                <Route path="/blog/ladd" element={<BlogAdd />} />
                <Route path="/blog/ledit" element={<EditBlog />} />
                <Route path="/blog/list" element={<TableBlog />} />
              
                {/* Members */}
                <Route path="/members/add" element={<AddMember />} />
                <Route path="/members/edit" element={<MemberEdit />} />  
                <Route path="/members/password/update" element={<MemberPasswordUpdate />} />              
                <Route path="/members/list" element={<TableMember />} />

                {/* Gift */}
                <Route path="/gift/add" element={<GiftForm />} />
                <Route path="/gift/edit" element={<GiftEdit />} />
                <Route path="/gift/list" element={<TableGift />} />
                {/* Reports */}
                <Route path="/gift/levelwise" element={<LevelWise />} />
                 <Route path="/gift/given" element={<GiftGiven />} />
                <Route path="/form/post" element={<PostForm />} />
                {/* 404 Page */}
              </Routes>
              <Outlet></Outlet>
            </BrowserRouter>
          </main>
        </>
      ) : (
        <>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/login" element={<Login />} />
              {/* 404 Page */}
              <Route path="*" element={<Login />} />
            </Routes>
            <Outlet></Outlet>
          </BrowserRouter>
        </>
      )}
    </>
  );
}

export default App;
